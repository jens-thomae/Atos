### Budgets: `/tmp/tmp.1vYrxEeH9v/iced-small`

| Metric | Budget | Measured | Result |
| --- | --- | --- | --- |
| Cold start to first frame | ≤ 300 ms | 51 ms | ✅ pass |
| Idle RSS (5 s after first frame) | ≤ 800 MB | 34.0 MB | ✅ pass |
| Idle CPU | ≤ 1 % over 300 s | 0.01 % | ✅ pass |
