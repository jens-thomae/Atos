### Budgets: `/tmp/tmp.1vYrxEeH9v/iced-wgpu-small`

| Metric | Budget | Measured | Result |
| --- | --- | --- | --- |
| Cold start to first frame | ≤ 300 ms | 130 ms | ✅ pass |
| Idle RSS (5 s after first frame) | ≤ 800 MB | 119.4 MB | ✅ pass |
| Idle CPU | ≤ 1 % over 300 s | 0.00 % | ✅ pass |
