### Budgets: `/tmp/tmp.8lhTQ7LzRr/slint-fork-a11y-small`

| Metric | Budget | Measured | Result |
| --- | --- | --- | --- |
| Cold start to first frame | ≤ 300 ms | 121 ms | ✅ pass |
| Idle RSS (5 s after first frame) | ≤ 800 MB | 102.9 MB | ✅ pass |
| Idle CPU | ≤ 1 % over 300 s | 0.02 % | ✅ pass |
