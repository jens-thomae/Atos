### Budgets: `/tmp/tmp.8lhTQ7LzRr/iced-wgpu-10k`

| Metric | Budget | Measured | Result |
| --- | --- | --- | --- |
| Cold start to first frame | ≤ 300 ms | 153 ms | ✅ pass |
| Idle RSS (5 s after first frame) | ≤ 800 MB | 122.9 MB | ✅ pass |
| Idle CPU | ≤ 1 % over 10 s | 0.00 % | ✅ pass |
